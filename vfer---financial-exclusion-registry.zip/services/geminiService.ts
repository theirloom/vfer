import { GoogleGenAI } from "@google/genai";

// Initialize the Gemini AI client. 
// @security: API_KEY is loaded from the environment to prevent hardcoding secrets.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Retrieves concise, reassuring safety advice for elderly users.
 * 
 * @param topic - The subject matter (e.g., "fraud prevention").
 * @returns A promise resolving to a string of bullet points.
 * 
 * @reliability This function implements a try/catch block to ensure that if the AI service 
 * is unavailable or rate-limited, the application gracefully falls back to static, 
 * pre-approved safety messaging. This ensures high availability.
 */
export const getSafetyAdvice = async (topic: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      // Prompt engineering: restricting output to "short, punchy" bullet points to minimize token usage and cost.
      contents: `Provide 3 short, punchy, and reassuring bullet points about "${topic}" specifically tailored for elderly Canadians to help them feel secure about their finances. Return only the bullet points.`,
    });
    return response.text || "Stay vigilant and monitor your accounts regularly.";
  } catch (error) {
    // Log error for observability but do not disrupt user experience.
    console.error("Gemini API Error:", error);
    return "Secure your financial future with the Voluntary Exclusion Registry.";
  }
};

/**
 * Generates a simple explanation of complex regulatory terms.
 * 
 * @param query - The regulatory concept to explain.
 * @returns A simplified string explanation under 50 words.
 * 
 * @cost-optimization Using 'gemini-3-flash-preview' provides a balance of speed and 
 * lower inference costs compared to larger models, aligning with the "low operational cost" requirement.
 */
export const explainRegulation = async (query: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Explain the following regulatory concept simply for a general audience, relating it to fraud prevention: "${query}". Keep it under 50 words.`,
    });
    return response.text || "Regulation ensures financial institutions verify identities to prevent unauthorized transactions.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Regulatory compliance is essential for system integrity.";
  }
};
